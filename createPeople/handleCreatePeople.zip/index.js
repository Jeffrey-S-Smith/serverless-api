'use strict';

const dynamoose = require('dynamoose');

const schema = new dynamoose.Schema({
  id: {
    type: String,
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  age: {
    type: Number,
  },
  married: {
    type: Boolean,
  },
});

const peopleModel = dynamoose.model('People', schema);

exports.handler = async (event) => {

  // create a new people
  let peopleData = new peopleModel({ id: 'test', name: 'test', age: 'test' , married: 'test'});
  let peopleRecord = await peopleData.save(); // talks to the database.


  return {
    statusCode: 200,
    body: JSON.stringify(peopleRecord)
  }
}