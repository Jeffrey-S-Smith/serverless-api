'use strict';

const schema = require('../schema/index.js');

exports.handler = async (event) => {

  let schemaData = [];

 
  if (event.pathParameters && event.pathParameters.id) {
    schemaData = await schema.query('id').eq(event.pathParameters.id).exec();
  } else {
    schemaData = await schema.scan().exec();
  }

  return {
    statusCode: 200,
    body: JSON.stringify(schemaData),
  }
}